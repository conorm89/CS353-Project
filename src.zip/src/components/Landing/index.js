import React from 'react';

const Landing = () => (
  <div>
    <h1>Landing</h1>
  </div>
);

export default Landing;