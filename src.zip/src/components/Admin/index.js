/**protected admin page!!
 On the admin page, a user authorized as admin will 
 be able to manage this application’s users. The admin 
 page is protected on a more fine-grained level, because 
 it is only accessible for authenticated admin users.*/
import React from 'react';

const Admin = () => (
  <div>
    <h1>Admin</h1>
  </div>
);

export default Admin;